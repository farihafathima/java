package lab1;

public class PersonEnum {

}
