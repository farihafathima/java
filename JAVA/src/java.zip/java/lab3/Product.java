package lab3;
import java.util.Arrays;
public class Product {

		    public static void main(String[] args) {
		        String[] products = { "LapTop", "Table", "Monitor", "KeyBoard" };
		        Arrays.sort(products);
		        
		        for (String product : products) {
		            System.out.println(product);
		        }
		    }}
